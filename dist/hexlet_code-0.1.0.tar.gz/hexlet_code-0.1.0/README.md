### Hexlet tests and linter status:
[![Actions Status](https://github.com/kochetkoov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/kochetkoov/python-project-49/actions)
python-project-49/brain_calc_demo.cast
