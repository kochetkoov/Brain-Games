#!/usr/bin/env python3

from brain_games.games.prime import play_prime_game


def main():
    play_prime_game()


if __name__ == '__main__':
    main()
